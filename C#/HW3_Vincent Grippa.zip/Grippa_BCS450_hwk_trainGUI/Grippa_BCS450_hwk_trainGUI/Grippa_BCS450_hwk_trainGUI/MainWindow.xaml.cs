﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Grippa_BCS450_hwk_trainScheduleDLL;
using Microsoft.Win32;
using System.IO;
using System.Runtime.Serialization.Json;

//***********************************************
// File: MainWindow.xaml.cs
//
// Purpose: This program is used to run train GUI created for Homework 3.
//          This section will be updated if necessary. 
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 11/5/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainGUI
{

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //Member variable declaration.
        StationCollection stationCollectionInstance = new StationCollection();

        public MainWindow()
        {
            InitializeComponent();
        }

        //***************************************************************
        //Method: Openbutton_Click
        //
        //Purpose: This method allows the user to select a file to load data into the stationCollection instance.
        //
        //***************************************************************
        private void Openbutton_Click(object sender, RoutedEventArgs e)
        {
            //Variables
            string fileName = null;
            string filePath = null;

            //Sets up the open file dialog.
            //Only allowing the .json extension, setting the intial directory to the current working directory,
            //and setting the title.
            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "Json(.json)|*.json";
            openFile.Title = "Open StationCollection From JSON";
            openFile.CheckPathExists = true;

            string currentDirect = System.IO.Directory.GetCurrentDirectory();

            openFile.InitialDirectory = currentDirect;
            openFile.ShowDialog();
            fileName = openFile.SafeFileName;
            filePath = openFile.FileName;

            if (fileName=="")
            {
                MessageBox.Show("Notice to User: No file selected.");
            }
            else if (fileName != null)
            {
                FileNametextBox.Text = filePath;
                displayInfo(fileName);
            }

        }//End openbutton_click

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        private void displayInfo(String fileN)
        {
            FileStream readerJSON = new FileStream(fileN, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer inputSerializerJSONStation;
            inputSerializerJSONStation = new DataContractJsonSerializer(typeof(StationCollection));

            stationCollectionInstance = (StationCollection)inputSerializerJSONStation.ReadObject(readerJSON);
            readerJSON.Close();

            for (int i = 0; i < stationCollectionInstance.stations.Count(); i++)
            {
                listViewTrain.Items.Add(stationCollectionInstance.stations[i]);
            }//End for loop
        }

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        private void ShowStationbutton_Click(object sender, RoutedEventArgs e)
        {
            
            Station stationFound= new Station();
            int stationNum;
            Int32.TryParse(StationIdtextBox.Text,out stationNum);


            if (stationCollectionInstance.stations.Count > 0 && stationNum > 0)
            {
                stationFound = stationCollectionInstance.FindStation(stationNum);

                NametextBox.Text = stationFound.name;
                LocationtextBox.Text = stationFound.location;
                FareZonetextBox.Clear();
                FareZonetextBox.Text += stationFound.fare_zone;
                MileagetextBox.Clear();
                MileagetextBox.Text += stationFound.mileage_to_penn;
                PictextBox.Text = stationFound.pic_Filename;
            }//End if starting on Line 104
            else if (stationCollectionInstance.stations.Count==0)
            {
                MessageBox.Show("No station collection has been loaded in, so unable to obtain station data.\nPlease load in station collection and try again.");
            }//End else if
        }
    }//End class

}//End namespace
