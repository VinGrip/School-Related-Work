﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: StationArrival.cs
//
// Purpose: Contains the class defintions for StationArrival class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/15/17
//
// Compiler: Visual Studio 2015
//****************************************************


namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class StationArrival
    {
        #region StationArrival private member variables
        private int m_stationId;
        private DateTime m_time;
        private int m_TrainId;
        //private bool transferRequired; <The following is deprecated according to specifications given. 

        #endregion

        #region Station properites

        [DataMember(Name = "station_id")]
        public int station_id
        {
            get
            {
                return m_stationId;
            }

            set
            {
                m_stationId = value;
            }
        }//End m_stationId property

        [DataMember(Name = "time")]
        public DateTime time
        {
            get
            {
                return m_time;
            }

            set
            {
                m_time = value;
            }
        }//End m_time property

        [DataMember(Name = "train_id")]
        public int train_id
        {
            get
            {
                return m_TrainId;
            }

            set
            {
                m_TrainId = value;
            }
        }//End m_TrainId property

        //The following property is deprecated according to specifications given in Homework 2. 
        #region transferProperty
        //[DataMember(Name = "transfer_required")]
        //public bool transferProperty
        //{
        //get
        //{
        //return transferRequired;
        //}

        //set
        //{
        //transferRequired = value;
        //}
        //}//End transferRequired property

        #endregion

        #endregion
            
        #region StationArrival methods

        //***************************************************************
        //Method: StationArrival
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public StationArrival()
        {
            //The following values are taken from the JSON example in Assignment 1's Serialization section.
            m_stationId = 2;
            m_time = DateTime.Parse("8/28/2017 9:25 AM");
            m_TrainId = 1;
        }

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive =
                "Station Id: " + m_stationId + "\n" +
                "Time: " + time.ToString() + "\n" +
                "Train Id: " + m_TrainId + "\n";

            return toStringDescriptive;
        }
        #endregion
    }
}
