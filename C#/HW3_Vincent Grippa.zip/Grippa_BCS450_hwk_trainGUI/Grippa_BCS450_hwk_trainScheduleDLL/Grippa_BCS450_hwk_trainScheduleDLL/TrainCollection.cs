﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: TrainCollection.cs
//
// Purpose: Contains the class defintions for TrainCollection class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/15/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class TrainCollection
    {
        #region TrainCollection private member variables
        private List<Train> m_trains = new List<Train>();

        #endregion

        #region TrainCollection properites

        [DataMember(Name = "trains")]

        public List<Train> trains
        {
            get
            {
                return m_trains;
            }

            set
            {
                m_trains = value;
            }
        }//End m_trains property
        #endregion

        #region TrainCollection methods

        //***************************************************************
        //Method: TrainCollection
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public TrainCollection()
        {
            m_trains = new List<Train>();

            m_trains = trains.ToList();
            foreach (Train train in m_trains)
            {
                m_trains.Add(new Train()
                {
                    id = train.id,
                    station_arrivals = train.station_arrivals
                });

            }//End foreach loop

        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive = null;

            m_trains = trains.ToList();
            for (int i = 0; i < m_trains.Count; i++)
            {
                toStringDescriptive += m_trains[i].ToString();
            }//End foreach loop

            return toStringDescriptive;
        }//End toString method

        //***************************************************************
        //Method: FindTrain
        //
        //Purpose: Returns the Station Object with the given station id. If it's not found return null.
        //
        //***************************************************************
        public Train FindTrain(int trainID)
        {
            Train result = null;
            foreach (Train tempTrain in m_trains)
            {
                if (tempTrain.id == trainID)
                {
                    result = tempTrain;
                }
            }//End foreach loop
            if (result == null)
            {
                //Intentionally left blank.
            }
            return result;

        }//End FindStation via Station Id method.

        #endregion

    }//End class

}//End namespace