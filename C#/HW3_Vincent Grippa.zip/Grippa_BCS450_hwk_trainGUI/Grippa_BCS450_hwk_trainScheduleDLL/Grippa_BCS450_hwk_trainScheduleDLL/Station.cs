﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: Station.cs
//
// Purpose: Contains the class defintions for Station class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/15/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class Station
    {
        #region Station private member variables
        private int m_id;
        private string m_name;
        private string m_location;
        private int m_fareZone;
        private double m_mileageToPenn;
        private string m_picFilename;

        #endregion

        #region Station properties 

        // C# Property for id
        [DataMember(Name = "id")]
        public int id
        {
            get
            {
                return m_id;
            }

            set
            {
                m_id = value;
            }
        }//End id property

        // C# Property for name
        [DataMember(Name = "name")]
        public string name
        {
            get
            {
                return m_name;
            }

            set
            {
                m_name = value;
            }
        }//End name property

        // C# Property for location
        [DataMember(Name = "location")]
        public string location
        {
            get
            {
                return m_location;
            }

            set
            {
                m_location = value;
            }
        }//End location property

        // C# Property for fareZone
        [DataMember(Name = "fare_zone")]
        public int fare_zone
        {
            get
            {
                return m_fareZone;
            }

            set
            {
                m_fareZone = value;
            }
        }//End fareZone property

        // C# Property for mileageToPenn
        [DataMember(Name = "mileage_to_penn")]
        public double mileage_to_penn
        {
            get
            {
                return m_mileageToPenn;
            }

            set
            {
                m_mileageToPenn = value;
            }
        }//End mileageToPenn property

        // C# Property for picFilename
        [DataMember(Name = "pic_filename")]
        public string pic_Filename
        {
            get
            {
                return m_picFilename;
            }

            set
            {
                m_picFilename = value;
            }
        }//End picFilename property


        #endregion

        #region Station methods

        //***************************************************************
        //Method: Station
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public Station()
        {
            //The following values are taken from the JSON example in Assignment 1's Serialization section.
            id = 111;
            name = "Huntington";
            location = "New York Avenue (Route 110) and Broadway,2 miles North of Jericho Turnpike.";
            fare_zone = 9;
            mileage_to_penn = 34.7;
            pic_Filename = "huntington.jpg";

        }

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
            public String ToString()
        {
            String toStringDescriptive =
                "Name: " + name + "\n" +
                "Location: " + location + "\n" +
                "Id: " + id + "\n" +
                "Fare Zone:" + fare_zone + "\n" +
                "Mileage to Penn: " + mileage_to_penn + "\n" +
                "Picture filename: " + pic_Filename + "\n\n";
            return toStringDescriptive;
        }

        #endregion
    }
}
