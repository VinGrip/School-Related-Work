﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: Branch.cs
//
// Purpose: Contains the class defintions for Branch class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/16/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class Branch
    {
        #region Branch private member variables
        private int m_id;
        private string m_name;
        private List<int> m_stationIds = new List<int>();
        #endregion

        #region Branch properites

        [DataMember(Name = "id")]
        public int id
        {
            get
            {
                return m_id;
            }

            set
            {
                m_id = value;
            }
        }//End m_id property

        [DataMember(Name = "name")]
        public string name
        {
            get
            {
                return m_name;
            }

            set
            {
                m_name = value;
            }
        }//End m_name property

        [DataMember(Name = "station_ids")]
        public List<int> station_ids
        {
            get
            {
                return m_stationIds;
            }

            set
            {
                m_stationIds = value;
            }
        }//End m_stationIds property

        #endregion

        #region Branch methods

        //***************************************************************
        //Method: Branch
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public Branch()
        {
            int temp = 0; ;
            //The following variables were taken from the specifications
            m_id = 2;
            m_name = "Port Jefferson";
            
            m_stationIds = new List<int>();

            for (int i = 0; i < m_stationIds.Count; i++)
            {
                temp = m_stationIds.ElementAt(i);
                m_stationIds.Add(temp);
            }
            m_stationIds.Add(10);
            m_stationIds.Add(11);
            m_stationIds.Add(12);
            m_stationIds.Add(13);
            m_stationIds.Add(14);

        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive = null;
            m_stationIds = station_ids.ToList();
            toStringDescriptive +=name+" Branch\n";
            toStringDescriptive +="Stations:\n";

            for (int i = 0; i < m_stationIds.Count; i++)
            {
                toStringDescriptive+=m_stationIds[i]+"\n";
            }//End for loop

            return toStringDescriptive;
        }//End toString method

        //***************************************************************
        //Method: isBranchStation
        //
        //Purpose: Returns true if the given station id is a station on the branch and false otherwise.
        //
        //***************************************************************
        public bool IsBranchStation(int stationId)
        {
            bool result = false;
            for (int i=0; i< m_stationIds.Count;i++)
            {
                if (m_stationIds[i] == stationId)
                {
                    result = true;
                }
                else
                {
                    //Intentionally left blank.
                }
            }//End foreach loop

            return result;

        }//End IsBranchStation method

        #endregion
    }//End class

}//End namespace