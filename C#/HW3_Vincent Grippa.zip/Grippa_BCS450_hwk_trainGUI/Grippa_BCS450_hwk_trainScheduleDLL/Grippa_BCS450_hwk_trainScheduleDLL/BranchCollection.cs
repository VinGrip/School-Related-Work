﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: BranchCollection.cs
//
// Purpose: Contains the class defintions for BranchCollection class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By: Vincent Grippa Jr
//
// Last Updated: 10/16/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class BranchCollection
    {
        #region BranchCollection private member variables
        private List<Branch> m_branches;

        #endregion

        #region BranchCollection properites

        [DataMember(Name = "branches")]
        public List<Branch> branches
        {
            get
            {
                return m_branches;
            }

            set
            {
                m_branches = value;
            }
        }//End m_branches property
        #endregion

        #region BranchCollection methods

        //***************************************************************
        //Method: BranchCollection
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public BranchCollection()
        {
            m_branches = new List<Branch>();

            foreach (Branch branch in m_branches)
            {
                m_branches.Add(new Branch()
                {
                    id = branch.id,
                    name = branch.name,
                    station_ids = branch.station_ids
                });
            }//End foreach loop

        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive = null;

            m_branches = branches.ToList();
            for (int i = 0; i < m_branches.Count; i++)
            {
                toStringDescriptive += m_branches[i].ToString();
            }//End for loop

            return toStringDescriptive;
        }//End toString method

        //***************************************************************
        //Method: FindBranch
        //
        //Purpose: Returns true if the given station id is a station on the branch and false otherwise.
        //
        //***************************************************************
        public Branch FindBranch(int branchID)
        {
            Branch result = null;
            foreach (Branch tempBranch in m_branches)
            {
                if (tempBranch.id == branchID)
                {
                    result = tempBranch;
                }
            }//End foreach loop
            if (result == null)
            {
                //Intentionally left blank.
            }
            return result;

        }//End FindBranch via Branch Id method.

        //***************************************************************
        //Method: FindBranch
        //
        //Purpose: Returns the Station Object with the given station name. If it's not found return null.
        //
        //***************************************************************
        public Branch FindBranch(string name)
        {
            Branch result = null;
            foreach (Branch tempBranch in m_branches)
            {
                if (tempBranch.name == name)
                {
                    result = tempBranch;
                }
            }//End foreach loop
            if (result == null)
            {
                //Intentionally left blank.
            }
            return result;
        }//End FindBranch via Name method.

        #endregion
    }//End class

}//End namespace