﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: TrainScheduleUnitTesting.cs
//
// Purpose: Contains the class defintions for TrainScheduleUnitTesting class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/14/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
 public class TrainScheduleUnitTesting
    {
            #region TrainScheduleUnitTesting private member variables
            //No private member variables as per the documentation.

            #endregion

            #region TrainScheduleUnitTesting properties
            //No properties as per the documentation.
            #endregion

            #region TrainScheduleUnitTesting methods

            //***************************************************************
            //Method: UnitTestStation
            //
            //Purpose: This method should declare an instance of Station inside of it and perform unit testing on all the properties of that instance.
            //
            //***************************************************************
            public void UnitTestStation()
            {
                Station test = new Station();
                int testId= 100; //This id was randomly chosen.
                string testFileName="image.jpg"; //This file name was also randomly chosen.

                //The following information was taken from: http://lirr42.mta.info/stationInfo.php?id=109 
                string testName ="Merrick";
                string testLocation= "Sunrise Highway (Route 27), between Hewlett Avenue and Merrick Avenue.";
                int testfareZone=7;
                double testMileage=24.1;
                
                //The following code is to test that the id property (both get and set) work.
                test.id = testId;

                if (test.id == testId)
                {
                    Console.WriteLine("Station Id Property: Pass");
                }
                else
                {
                    Console.WriteLine( "Station Id Property: FAIL!");
                }

                //The following code is to test that the name property (both get and set) work.
                test.name = testName;

                if (test.name == testName)
                {
                    Console.WriteLine("Station Name Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station Name Property: FAIL!");
                }

                //The following code is to test that the Location property (both get and set) work.
                test.location = testLocation;

                if (test.location == testLocation)
                {
                    Console.WriteLine("Station Location Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station Location Property: FAIL!");
                }

                //The following code is to test that the fareZone property (both get and set) work.
                test.fare_zone = testfareZone;

                if (test.fare_zone == testfareZone)
                {
                    Console.WriteLine("Station fareZone Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station fareZone Property: FAIL!");
                }

                //The following code is to test that the MileageToPenn property (both get and set) work.
                test.mileage_to_penn = testMileage;

                if (test.mileage_to_penn == testMileage)
                {
                    Console.WriteLine("Station MileageToPenn Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station MileageToPenn Property: FAIL!");
                }

                //The following code is to test that the picFilename property (both get and set) work.
                test.pic_Filename = testFileName;

                if (test.pic_Filename == testFileName)
                {
                    Console.WriteLine("Station picFilename Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station picFilename Property: FAIL!");
                }

                //To give space between the properties testing and the toString testing. Intentionally left blank.
                Console.WriteLine();

                //To show that the default constructor works. You see the constrtor works because the ToString has the default values.
                Station test2 = new Station();

                //The following code is to test the ToString method of Station.
                Console.WriteLine("ToString method test:\n");
                Console.Write(test2.ToString());

            }//End UnitTestStation

            //***************************************************************
            //Method: UnitTestStationArrival
            //
            //Purpose: This method should declare an instance of StationArrival inside of it and perform unit testing on all the properties of that instance.
            //
            //***************************************************************
            public void UnitTestStationArrival()
            {
                StationArrival test = new StationArrival();
                //The following test variables were randomly chosen.
                int testId=22;
                DateTime testTime= DateTime.Parse("5/08/2017 10:25 AM");
                int train_id = 1;


                //The following code is to test that the id property (both get and set) work.
                test.station_id = testId;

                if (test.station_id == testId)
                {
                    Console.WriteLine("StationArrival Id Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Id Property: FAIL!");
                }

                //The following code is to test that the time property (both get and set) work.
                test.time = testTime;

                if (test.time == testTime)
                {
                    Console.WriteLine("StationArrival Time Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Time Property: FAIL!");
                }

            //The following code is to test that the train_id (both get and set) work.
            test.train_id = train_id;

                if (test.train_id == train_id)
                {
                    Console.WriteLine("StationArrival Train Id Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Train Id Property: FAIL!");
                }

                //To give space between the properties testing and the toString testing. Intentionally left blank.
                Console.WriteLine();
                //Console.WriteLine();

                //To show that the default constructor works. You see the constrtor works because the ToString has the default values.
                StationArrival test2 = new StationArrival();

                //The following code is to test the ToString method of Station.
                Console.WriteLine("ToString method test:\n");
                Console.Write(test2.ToString());

            }//End UnitTestStationArrival method

        #endregion
    }//End Class

}//End Namespace