﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: BranchSchedule.cs
//
// Purpose: Contains the class defintions for BranchSchedule class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/16/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class BranchSchedule
    {
        #region BranchSchedule private member variables
        private int m_branchId;
        private List<int> m_trainIds;

        #endregion

        #region BranchSchedule properites

        [DataMember(Name = "id")]
        public int id
        {
            get
            {
                return m_branchId;
            }

            set
            {
                m_branchId = value;
            }
        }//End m_stationId property

        [DataMember(Name = "train_ids")]
        public List<int> train_ids
        {
            get
            {
                return m_trainIds;
            }

            set
            {
                m_trainIds = value;
            }
        }//End m_time property

        #endregion

        #region BranchSchedule methods

        //***************************************************************
        //Method: BranchSchedule
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public BranchSchedule()
        {
            //The following variables are taken from the specifications.
            m_branchId = 0;
            m_trainIds.Add(1623);
            m_trainIds.Add(1205);

        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            string toStringDescriptive = null;
            toStringDescriptive += "Branch ID:" + m_branchId + "\n Train Ids:";
            foreach (int temp in m_trainIds)
            {
                toStringDescriptive +=m_trainIds +" ";
            }
            toStringDescriptive += "\n";
            
            return toStringDescriptive;
        }//End toString method

        #endregion

    }//End class

}//End namespace