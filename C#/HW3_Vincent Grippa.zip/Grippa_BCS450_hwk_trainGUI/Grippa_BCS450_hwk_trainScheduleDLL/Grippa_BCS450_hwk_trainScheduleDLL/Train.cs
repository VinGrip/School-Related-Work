﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: Train.cs
//
// Purpose: Contains the class defintions for Train class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/16/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class Train
    {
        #region Train private member variables
        private int m_trainId;
        private List<StationArrival> m_StationArrivals;

        #endregion

        #region Train properites

        [DataMember(Name = "id")]
        public int id
        {
            get
            {
                return m_trainId;
            }

            set
            {
                m_trainId = value;
            }
        }//End m_trainId property

        [DataMember(Name = "station_arrivals")]
        public List<StationArrival> station_arrivals
        {
            get
            {
                return m_StationArrivals;
            }

            set
            {
                m_StationArrivals = value;
            }
        }//End m_StationArrivals property
        #endregion

        #region Train methods

        //***************************************************************
        //Method: Train
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public Train()
        {
            //The following variables were taken from the specifications
            m_trainId = 2;
            m_StationArrivals = new List<StationArrival>();

            foreach (StationArrival station in m_StationArrivals)
            {
                m_StationArrivals.Add(new StationArrival()
                {
                    station_id = station.station_id,
                    time = station.time,
                    train_id = station.train_id,
                });

            }//End foreach loop

        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive = null;

            m_StationArrivals = station_arrivals.ToList();
            toStringDescriptive += "\nTrain number " + id+"\n";
            for (int i = 0; i < m_StationArrivals.Count; i++)
            {
                toStringDescriptive += m_StationArrivals[i].ToString();
            }//End for loop

            return toStringDescriptive;
        }//End toString method

        #endregion
    }//End class

}//End namespace