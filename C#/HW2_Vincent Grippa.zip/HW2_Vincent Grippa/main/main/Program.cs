﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Grippa_BCS450_hwk_trainScheduleDLL;
using System.IO;
using System.Runtime.Serialization.Json;

//***********************************************
// File: Program.cs
//
// Purpose: This program is used to run the menu given in Homework 2.
//          This section will be updated if necessary. 
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/16/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace main
{
    public class Program
    {
        static void Main(string[] args)
        {
            #region Class instances To be inserted
            Grippa_BCS450_hwk_trainScheduleDLL.StationCollection stationCollectionInstance = new Grippa_BCS450_hwk_trainScheduleDLL.StationCollection();
            Grippa_BCS450_hwk_trainScheduleDLL.Branch branchInstance = new Grippa_BCS450_hwk_trainScheduleDLL.Branch();
            Grippa_BCS450_hwk_trainScheduleDLL.BranchCollection branchCollectionInstance = new Grippa_BCS450_hwk_trainScheduleDLL.BranchCollection();
            Grippa_BCS450_hwk_trainScheduleDLL.TrainCollection trainCollectionInstance = new Grippa_BCS450_hwk_trainScheduleDLL.TrainCollection();

            #endregion

            #region Menu Display Code
            int choice = 0;
            string tempValue = "";

            while (choice != 13)
            {
                Console.Write("\nTrain Schedule Menu\n");
                Console.WriteLine("----------");
                Console.WriteLine("1-Read StationCollection from JSON file");
                Console.WriteLine("2-Read StationCollection from XML file");
                Console.WriteLine("3-Write StationCollection to JSON file");
                Console.WriteLine("4-Write StationCollection to XML file");
                Console.WriteLine("5-Display StationCollection data on screen");
                Console.WriteLine("6-Show station data by name(alphabetically sorted A to Z)");
                Console.WriteLine("7-Read BranchCollection from JSON file");
                Console.WriteLine("8-Write BranchCollection to JSON file");
                Console.WriteLine("9-Display BranchCollection data on screen");
                Console.WriteLine("10-Read TrainCollection from JSON file ");
                Console.WriteLine("11-Write TrainCollection to JSON file ");
                Console.WriteLine("12-Display TrainCollection data on screen");
                Console.WriteLine("13-Exit");
                Console.WriteLine("Enter Choice:");

                tempValue = Console.ReadLine();
                Int32.TryParse(tempValue,out choice);

                Console.WriteLine("User selected choice is :" + choice + "\n");

                switch(choice)
                {
                    case 1: //Read StationCollection from JSON file
                        Console.WriteLine("Enter the file name you would like to read from (Example: stationCollection.json):");
                        String filenameReadJSONStation = (Console.ReadLine());
                        FileStream readerJSONStation = new FileStream(filenameReadJSONStation, FileMode.Open, FileAccess.Read);

                        DataContractJsonSerializer inputSerializerJSONStation;
                        inputSerializerJSONStation = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationCollection));

                        stationCollectionInstance = (StationCollection)inputSerializerJSONStation.ReadObject(readerJSONStation);
                        readerJSONStation.Close();

                        break;

                    case 2: //Read StationCollection from XML file
                        Console.WriteLine("Enter the file name you would like to read from (Example: stationCollection.xml):");
                        String filenameReadXMLStation = (Console.ReadLine());
                        FileStream readerXMLStation = new FileStream(filenameReadXMLStation, FileMode.Open, FileAccess.Read);

                        DataContractSerializer inputSerializerXMLStation;
                        inputSerializerXMLStation = new DataContractSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationCollection));

                        stationCollectionInstance = (StationCollection)inputSerializerXMLStation.ReadObject(readerXMLStation);
                        readerXMLStation.Close();
                        break;

                    case 3: //Write StationCollection to JSON file
                        Console.WriteLine("Enter the file name you would like to write from (Example: stationCollection.json):");
                        String filenameWriteJSONStation = (Console.ReadLine());
                        FileStream writerJSONStation = new FileStream(filenameWriteJSONStation, FileMode.Create, FileAccess.Write);

                        DataContractJsonSerializer serJSONStation;
                        serJSONStation = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationCollection));

                        serJSONStation.WriteObject(writerJSONStation, stationCollectionInstance);
                        writerJSONStation.Close();

                        Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameWriteJSONStation);

                        break;

                    case 4: //Write StationCollection to XML file
                        Console.WriteLine("Enter the file name you would like to write from (Example: stationCollection.json):");
                        String filenameWriteXMLStation = (Console.ReadLine());
                        FileStream writerXMLStation= new FileStream(filenameWriteXMLStation, FileMode.Create, FileAccess.Write);

                        DataContractJsonSerializer serXMLStation;
                        serXMLStation = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationCollection));

                        serXMLStation.WriteObject(writerXMLStation, stationCollectionInstance);
                        writerXMLStation.Close();

                        Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameWriteXMLStation);

                        break;

                    case 5: //Display StationCollection data on screen
                        Console.WriteLine("---------------Begin Displaying Station Collection data on screen---------------");
                        Console.WriteLine(stationCollectionInstance.ToString());
                        Console.WriteLine("---------------End Displaying Station Collection data on screen---------------");

                        break;

                    case 6: //Show station data by name
                        Console.WriteLine("---------------Begin Displaying Station by name on screen---------------");
                        stationCollectionInstance.stations.OrderBy(Station => Station.name);
                        foreach (Station s in stationCollectionInstance.stations)
                        {
                            Console.Write(s.ToString());
                        }//End foreach loop
                        Console.WriteLine("---------------End displaying Station by name on screen---------------");

                        break;

                    case 7: //Read BranchCollection from JSON file
                        Console.WriteLine("Enter the file name you would like to read from (Example: branchCollection.json):");
                        String filenameReadJSONBranch = (Console.ReadLine());
                        FileStream readerJSONBranch = new FileStream(filenameReadJSONBranch, FileMode.Open, FileAccess.Read);

                        DataContractJsonSerializer inputSerializerJSONBranch;
                        inputSerializerJSONBranch = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.BranchCollection));

                        branchCollectionInstance = (BranchCollection)inputSerializerJSONBranch.ReadObject(readerJSONBranch);
                        readerJSONBranch.Close();

                        break;

                    case 8: //Write BranchCollection to JSON file
                        Console.WriteLine("Enter the file name you would like to write from (Example: branchCollection.json):");
                        String filenameWriteJSONBranch = (Console.ReadLine());
                        FileStream writerJSONBranch = new FileStream(filenameWriteJSONBranch, FileMode.Create, FileAccess.Write);

                        DataContractJsonSerializer serJSONBranch;
                        serJSONBranch = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.BranchCollection));

                        serJSONBranch.WriteObject(writerJSONBranch, branchCollectionInstance);
                        writerJSONBranch.Close();

                        Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameWriteJSONBranch);

                        break;

                    case 9: //Display BranchCollection data on screen
                        Console.WriteLine("---------------Begin Displaying Branch Collection data on screen---------------");
                        Console.WriteLine(branchCollectionInstance.ToString());
                        Console.WriteLine("---------------End Displaying Branch Collection data on screen---------------");

                        break;

                    case 10: //Read TrainCollection from JSON file
                        Console.WriteLine("Enter the file name you would like to read from (Example: trainCollection.json):");
                        String filenameReadJSONSTrain = (Console.ReadLine());
                        FileStream readerJSONTrain = new FileStream(filenameReadJSONSTrain, FileMode.Open, FileAccess.Read);

                        DataContractJsonSerializer inputSerializerJSONTrain;
                        inputSerializerJSONTrain = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.TrainCollection));

                        trainCollectionInstance = (TrainCollection)inputSerializerJSONTrain.ReadObject(readerJSONTrain);
                        readerJSONTrain.Close();

                        break;

                    case 11: //Write TrainCollection to JSON file
                        Console.WriteLine("Enter the file name you would like to write from (Example: trainCollection.json):");
                        String filenameWriteJSONTrain = (Console.ReadLine());
                        FileStream writerJSONTrain = new FileStream(filenameWriteJSONTrain, FileMode.Create, FileAccess.Write);

                        DataContractJsonSerializer serJSONTrain;
                        serJSONTrain = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.TrainCollection));

                        serJSONTrain.WriteObject(writerJSONTrain, trainCollectionInstance);
                        writerJSONTrain.Close();

                        Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameWriteJSONTrain);

                        break;

                    case 12: //Display TrainCollection data on screen
                        Console.WriteLine("---------------Begin Displaying Train Collection data on screen---------------");
                        Console.WriteLine(trainCollectionInstance.ToString());
                        Console.WriteLine("---------------End Displaying Train Collection data on screen---------------");

                        break;

                    case 13: // Exit
                        Console.WriteLine("Program terminated by user choice.");
                        break;

                    default:
                        Console.Clear();
                        Console.WriteLine("Input was: "+choice +". Invalid input. Screen cleared. Please try again.");
                        break;
                
                }//End switch

            }//End While loop
            #endregion

            #region Unit Testing Calls Currently (as of 10/14) deprecated.

            //Grippa_BCS450_hwk_trainScheduleDLL.TrainScheduleUnitTesting TrainTesting = new Grippa_BCS450_hwk_trainScheduleDLL.TrainScheduleUnitTesting();

            //TrainTesting.UnitTestStation();

            //To divide the two unit testing ouputs.
            //Console.WriteLine("\n****************************************************************\n");

            //TrainTesting.UnitTestStationArrival();

            //To divide the unit testing ouputs and the Serialization and Deserilization outputs.
            //Console.WriteLine("\n****************************************************************\n");

            #endregion

            #region JSON Serialization Currently (as of 10/14) deprecated.

            //The following code is for the Station Serialization.
            //Grippa_BCS450_hwk_trainScheduleDLL.Station serialize = new Grippa_BCS450_hwk_trainScheduleDLL.Station();
            //String filenameA1 = "station.json";
            //FileStream writerA = new FileStream(filenameA1, FileMode.Create,FileAccess.Write);
        
            //DataContractJsonSerializer serA1;
            //serA1 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.Station));

            //serA1.WriteObject(writerA, serialize);
            //writerA.Close();

            //Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameA1);

            //The following is for the Station DeSerialization.
            //Grippa_BCS450_hwk_trainScheduleDLL.Station deserializeA;
            //String filenameA2 = "station.json";
            //FileStream readerA = new FileStream(filenameA2, FileMode.Open, FileAccess.Read);

            //DataContractJsonSerializer inputSerializerA2;
            //inputSerializerA2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.Station));

            //deserializeA = (Grippa_BCS450_hwk_trainScheduleDLL.Station)inputSerializerA2.ReadObject(readerA);
            //readerA.Close();

            //Console.WriteLine("DESERIALIZATION(shows the JSON that was deserialized using the ToString method):\n" + deserializeA.ToString());

            //To divide the Serialization and Deserilization outputs of Station and StationArrival.
            //Console.WriteLine("\n****************************************************************\n");

            //*****************************************************************************************************

            //The following code is for the StationArrival Serialization.
            //Grippa_BCS450_hwk_trainScheduleDLL.StationArrival serialize2 = new Grippa_BCS450_hwk_trainScheduleDLL.StationArrival();
            //String filenameB = "stationArrival.json";
            //FileStream writerB = new FileStream(filenameB, FileMode.Create, FileAccess.Write);

            //DataContractJsonSerializer ser2;
            //ser2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationArrival));

            //ser2.WriteObject(writerB, serialize2);
            //writerB.Close();

            //Console.WriteLine("\nSERIALIZATION: StationArrival JSON printed to " + filenameB);

            //The following is for the StationArrival DeSerialization.
            //Grippa_BCS450_hwk_trainScheduleDLL.StationArrival deserializeB;
            //String filenameB2 = "stationArrival.json";
            //FileStream readerB = new FileStream(filenameB2, FileMode.Open, FileAccess.Read);

            //DataContractJsonSerializer inputSerializer2;
            //inputSerializer2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.StationArrival));

            //deserializeB = (Grippa_BCS450_hwk_trainScheduleDLL.StationArrival)inputSerializer2.ReadObject(readerB);
            //readerB.Close();

            //Console.WriteLine("DESERIALIZATION(shows the JSON that was deserialized using the ToString method):\n" + deserializeB.ToString());

            #endregion
        }
    }
}