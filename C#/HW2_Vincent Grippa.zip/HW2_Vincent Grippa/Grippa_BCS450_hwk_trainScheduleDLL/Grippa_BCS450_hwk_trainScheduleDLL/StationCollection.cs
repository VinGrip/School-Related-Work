﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Collections;

//***********************************************
// File: StationCollection.cs
//
// Purpose: Contains the class defintions for StationCollection class for the Train Schedule program I will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 10/19/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class StationCollection
    {
        #region StationCollection private member variables
        private List<Station> m_stations= new List<Station>();

        #endregion

        #region StationCollection properites

        [DataMember(Name = "stations")]
        
        public List<Station> stations
        {
            get
            {
                return m_stations;
            }

            set
            {
                m_stations = value;
            }
        }//End m_stationIds property
        #endregion

        #region StationCollection methods

        //***************************************************************
        //Method: StationCollection
        //
        //Purpose: Default constructor. Sets the values of each member variable to a default value.
        //
        //***************************************************************
        public StationCollection()
        {
            m_stations = new List<Station>();

            foreach (Station station in m_stations)
            {
                m_stations.Add(new Station()
                {
                    fare_zone = station.fare_zone,
                    id = station.id,
                    location = station.location,
                    mileage_to_penn = station.mileage_to_penn,
                    name = station.name,
                    pic_Filename = station.pic_Filename
                });

            }//End foreach loop
         
        }//End Default Constructor

        //***************************************************************
        //Method: ToString
        //
        //Purpose: This method should show descriptive text and data for all member variables.
        //
        //***************************************************************
        override
           public String ToString()
        {
            String toStringDescriptive = null;
            
            m_stations = stations.ToList();
                for (int i = 0; i < m_stations.Count; i++)
            {
                toStringDescriptive += m_stations[i].ToString();
                    
            }//End foreach loop

            return toStringDescriptive;
        }//End toString method

        //***************************************************************
        //Method: FindStation
        //
        //Purpose: Returns the Station Object with the given station id. If it's not found return null.
        //
        //***************************************************************
        public Station FindStation(int stationId)
        {
            Station result = null;
            foreach(Station tempStation in m_stations)
            {
                if (tempStation.id==stationId)
                {
                    result = tempStation;
                }
            }//End foreach loop
            if(result == null)
            {
                //Intentionally left blank.
            }
            return result;

        }//End FindStation via Station Id method.

            //***************************************************************
            //Method: FindStation
            //
            //Purpose: Returns the Station Object with the given station name. If it's not found return null.
            //
            //***************************************************************
        public Station FindStation(string name)
        {
            Station result = null;
            foreach (Station tempStation in m_stations)
            {
                if (tempStation.name == name)
                {
                    result = tempStation;
                }
            }//End foreach loop
            if (result == null)
            {
                //Intentionally left blank.
            }
            return result;
        }//End FindStation via Name method.

            #endregion

        }//End class

    }//End namespace
