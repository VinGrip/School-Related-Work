﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using Grippa_BCS450_hwk_trainScheduleDLL;
using System.IO;
using System.Runtime.Serialization.Json;

//***********************************************
// File: Program.cs
//
// Purpose: This program is used to call the unit testing of the classes created in the trainScheduleDLL.cs DLL which is imported into this solution.
//          This program is also used to do the JSON Serialization/Deserialization of the classes.
//          This section will be updated if necessary. 
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 9/24/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace main
{
    public class Program
    {
        static void Main(string[] args)
        {
            #region Unit Testing Calls

            Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.TrainScheduleUnitTesting TrainTesting = new Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.TrainScheduleUnitTesting();

            TrainTesting.UnitTestStation();
            
            //To divide the two unit testing ouputs.
            Console.WriteLine("\n****************************************************************\n");

            TrainTesting.UnitTestStationArrival();

            //To divide the unit testing ouputs and the Serialization and Deserilization outputs.
            Console.WriteLine("\n****************************************************************\n");

            #endregion

            #region JSON Serialization

            //The following code is for the Station Serialization.
            Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station serialize = new Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station();
            String filenameA1 = "station.json";
            FileStream writerA = new FileStream(filenameA1, FileMode.Create,FileAccess.Write);

            DataContractJsonSerializer serA1;
            serA1 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station));

            serA1.WriteObject(writerA, serialize);
            writerA.Close();

            Console.WriteLine("\nSERIALIZATION: Station JSON printed to " + filenameA1);

            //The following is for the Station DeSerialization.
            Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station deserializeA;
            String filenameA2 = "station.json";
            FileStream readerA = new FileStream(filenameA2, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer inputSerializerA2;
            inputSerializerA2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station));

            deserializeA = (Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.Station)inputSerializerA2.ReadObject(readerA);
            readerA.Close();

            Console.WriteLine("DESERIALIZATION(shows the JSON that was deserialized using the ToString method):\n" + deserializeA.ToString());

            //To divide the Serialization and Deserilization outputs of Station and StationArrival.
            Console.WriteLine("\n****************************************************************\n");

            //*****************************************************************************************************

            //The following code is for the StationArrival Serialization.
            Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival serialize2 = new Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival();
            String filenameB = "stationArrival.json";
            FileStream writerB = new FileStream(filenameB, FileMode.Create, FileAccess.Write);

            DataContractJsonSerializer ser2;
            ser2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival));

            ser2.WriteObject(writerB, serialize2);
            writerB.Close();

            Console.WriteLine("\nSERIALIZATION: StationArrival JSON printed to " + filenameB);

            //The following is for the StationArrival DeSerialization.
            Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival deserializeB;
            String filenameB2 = "stationArrival.json";
            FileStream readerB = new FileStream(filenameB2, FileMode.Open, FileAccess.Read);

            DataContractJsonSerializer inputSerializer2;
            inputSerializer2 = new DataContractJsonSerializer(typeof(Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival));

            deserializeB = (Grippa_BCS450_hwk_trainScheduleDLL.trainScheduleDLL.StationArrival)inputSerializer2.ReadObject(readerB);
            readerB.Close();

            Console.WriteLine("DESERIALIZATION(shows the JSON that was deserialized using the ToString method):\n" + deserializeB.ToString());

            #endregion
        }
    }
}