﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

//***********************************************
// File: trainScheduleDLL.cs
//
// Purpose: Contains the class defintions for Train Schedule program will be creating this semester.
//          This section will be updated if necessary.
//
// Written By:  Vincent Grippa Jr
//
// Last Updated: 9/24/17
//
// Compiler: Visual Studio 2015
//****************************************************

namespace Grippa_BCS450_hwk_trainScheduleDLL
{
    [DataContract]
    public class trainScheduleDLL
    {
        //Station Class Code
        public class Station
        {
            #region Station private member variables
            private int id;
            private string name;
            private string location;
            private int fareZone;
            private double mileageToPenn;
            private string picFilename;

            #endregion

            #region Station properties 

            // C# Property for id
            [DataMember(Name = "id")]
            public int idProperty
            {
                get
                {
                    return id;
                }

                set
                {
                    id = value;
                }
            }//End id property

            // C# Property for name
            [DataMember(Name = "name")]
            public string nameProperty
            {
                get
                {
                    return name;
                }

                set
                {
                    name = value;
                }
            }//End name property

            // C# Property for location
            [DataMember(Name = "location")]
            public string locationProperty
            {
                get
                {
                    return location;
                }

                set
                {
                    location = value;
                }
            }//End location property

            // C# Property for fareZone
            [DataMember(Name = "fare_zone")]
            public int fareZoneProperty
            {
                get
                {
                    return fareZone;
                }

                set
                {
                    fareZone = value;
                }
            }//End fareZone property

            // C# Property for mileageToPenn
            [DataMember(Name = "mileage_to_penn")]
            public double mileageToPennProperty
            {
                get
                {
                    return mileageToPenn;
                }

                set
                {
                    mileageToPenn = value;
                }
            }//End mileageToPenn property

            // C# Property for picFilename
            [DataMember(Name = "pic_filename")]
            public string picFilenameProperty
            {
                get
                {
                    return picFilename;
                }

                set
                {
                    picFilename = value;
                }
            }//End picFilename property


            #endregion

            #region Station methods

            //***************************************************************
            //Method: Station
            //
            //Purpose: Default constructor. Sets the values of each member variable to a default value.
            //
            //***************************************************************
            public Station()
            {
                //The following values are taken from the JSON example in Assignment 1's Serialization section.
                id = 111;
                name = "Huntington";
                location = "New York Avenue (Route 110) and Broadway,2 miles North of Jericho Turnpike.";
                fareZone = 9;
                mileageToPenn = 34.7;
                picFilename = "huntington.jpg";

            }

            //***************************************************************
            //Method: ToString
            //
            //Purpose: This method should show descriptive text and data for all member variables.
            //
            //***************************************************************
            override
                public String ToString()
            {
                String toStringDescriptive =
                    "Name: " + name + "\n" +
                    "Location: " + location + "\n" +
                    "Id: " + id + "\n" +
                    "Fare Zone:" + fareZone + "\n" +
                    "Mileage to Penn: " + mileageToPenn + "\n" +
                    "Picture filename: " + picFilename + "\n";
                return toStringDescriptive;
            }

            #endregion
        }

        //************************************************************

        //StationArrival Class Code
        public class StationArrival
        {
            #region StationArrival private member variables
            private int stationId;
            private DateTime time;
            private bool transferRequired;

            #endregion

            #region Station properites

            [DataMember(Name = "station_id")]
            public int stationIdProperty
            {
                get
                {
                    return stationId;
                }

                set
                {
                    stationId = value;
                }
            }//End stationId property

            [DataMember(Name = "time")]
            public DateTime timeProperty
            {
                get
                {
                    return time;
                }

                set
                {
                    time = value;
                }
            }//End time property

            [DataMember(Name = "transfer_required")]
            public bool transferProperty
            {
                get
                {
                    return transferRequired;
                }

                set
                {
                    transferRequired = value;
                }
            }//End transferRequired property

            #endregion

            #region StationArrival methods

            //***************************************************************
            //Method: StationArrival
            //
            //Purpose: Default constructor. Sets the values of each member variable to a default value.
            //
            //***************************************************************
            public StationArrival()
            {
                //The following values are taken from the JSON example in Assignment 1's Serialization section.
                stationId = 2;
                time = DateTime.Parse("8/28/2017 9:25 AM");
                transferRequired = true;

            }

            //***************************************************************
            //Method: ToString
            //
            //Purpose: This method should show descriptive text and data for all member variables.
            //
            //***************************************************************
            override
               public String ToString()
            {
                String toStringDescriptive =
                    "Station Id: " + stationId + "\n" +
                    "Time: " + time.ToString() + "\n" +
                    "Transfer Required: " + transferRequired + "\n";

                return toStringDescriptive;
            }
            #endregion
        }

        //************************************************************

        //TrainScheduleUnitTesting Class Code
        public class TrainScheduleUnitTesting
        {
            #region TrainScheduleUnitTesting private member variables
            //No private member variables as per the documentation.

            #endregion

            #region TrainScheduleUnitTesting properties
            //No properties as per the documentation.
            #endregion

            #region TrainScheduleUnitTesting methods

            //***************************************************************
            //Method: UnitTestStation
            //
            //Purpose: This method should declare an instance of Station inside of it and perform unit testing on all the properties of that instance.
            //
            //***************************************************************
            public void UnitTestStation()
            {
                Station test = new Station();
                int testId= 100; //This id was randomly chosen.
                string testFileName="image.jpg"; //This file name was also randomly chosen.

                //The following information was taken from: http://lirr42.mta.info/stationInfo.php?id=109 
                string testName ="Merrick";
                string testLocation= "Sunrise Highway (Route 27), between Hewlett Avenue and Merrick Avenue.";
                int testfareZone=7;
                double testMileage=24.1;
                
                //The following code is to test that the id property (both get and set) work.
                test.idProperty = testId;

                if (test.idProperty == testId)
                {
                    Console.WriteLine("Station Id Property: Pass");
                }
                else
                {
                    Console.WriteLine( "Station Id Property: FAIL!");
                }

                //The following code is to test that the name property (both get and set) work.
                test.nameProperty = testName;

                if (test.nameProperty == testName)
                {
                    Console.WriteLine("Station Name Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station Name Property: FAIL!");
                }

                //The following code is to test that the Location property (both get and set) work.
                test.locationProperty = testLocation;

                if (test.locationProperty == testLocation)
                {
                    Console.WriteLine("Station Location Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station Location Property: FAIL!");
                }

                //The following code is to test that the fareZone property (both get and set) work.
                test.fareZoneProperty = testfareZone;

                if (test.fareZoneProperty == testfareZone)
                {
                    Console.WriteLine("Station fareZone Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station fareZone Property: FAIL!");
                }

                //The following code is to test that the MileageToPenn property (both get and set) work.
                test.mileageToPennProperty = testMileage;

                if (test.mileageToPennProperty == testMileage)
                {
                    Console.WriteLine("Station MileageToPenn Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station MileageToPenn Property: FAIL!");
                }

                //The following code is to test that the picFilename property (both get and set) work.
                test.picFilenameProperty = testFileName;

                if (test.picFilenameProperty == testFileName)
                {
                    Console.WriteLine("Station picFilename Property: Pass");
                }
                else
                {
                    Console.WriteLine("Station picFilename Property: FAIL!");
                }

                //To give space between the properties testing and the toString testing. Intentionally left blank.
                Console.WriteLine();

                //To show that the default constructor works. You see the constrtor works because the ToString has the default values.
                Station test2 = new Station();

                //The following code is to test the ToString method of Station.
                Console.WriteLine("ToString method test:\n");
                Console.Write(test2.ToString());

            }//End UnitTestStation

            //***************************************************************
            //Method: UnitTestStationArrival
            //
            //Purpose: This method should declare an instance of StationArrival inside of it and perform unit testing on all the properties of that instance.
            //
            //***************************************************************
            public void UnitTestStationArrival()
            {
                StationArrival test = new StationArrival();
                //The following test variables were randomly chosen.
                int testId=22;
                DateTime testTime= DateTime.Parse("5/08/2017 10:25 AM");
                bool testTransfer = true;


                //The following code is to test that the id property (both get and set) work.
                test.stationIdProperty = testId;

                if (test.stationIdProperty == testId)
                {
                    Console.WriteLine("StationArrival Id Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Id Property: FAIL!");
                }

                //The following code is to test that the time property (both get and set) work.
                test.timeProperty = testTime;

                if (test.timeProperty == testTime)
                {
                    Console.WriteLine("StationArrival Name Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Name Property: FAIL!");
                }

                //The following code is to test that the transfer property (both get and set) work.
                test.transferProperty = testTransfer;

                if (test.transferProperty == testTransfer)
                {
                    Console.WriteLine("StationArrival Location Property: Pass");
                }
                else
                {
                    Console.WriteLine("StationArrival Location Property: FAIL!");
                }

                //To give space between the properties testing and the toString testing. Intentionally left blank.
                Console.WriteLine();
                //Console.WriteLine();

                //To show that the default constructor works. You see the constrtor works because the ToString has the default values.
                StationArrival test2 = new StationArrival();

                //The following code is to test the ToString method of Station.
                Console.WriteLine("ToString method test:\n");
                Console.Write(test2.ToString());

            }//End UnitTestStationArrival method

            #endregion
        }

    }//End Class

}//End Namespace