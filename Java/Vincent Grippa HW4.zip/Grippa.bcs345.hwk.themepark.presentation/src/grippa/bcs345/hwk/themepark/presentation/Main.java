package grippa.bcs345.hwk.themepark.presentation;

import java.util.Scanner;

/**
 * Main entry point for the program.
 * Contains main program code.
 * 
 * @author Vincent Grippa
 * @version 3.0
 * @since 4/15/2017
 *
*/
public class Main {

	/**
	 * Code used to call DailyAttractionUsageConsoleUI or ParkConsoleUI based on user choice.
	 * @param args
	 */
	public static void main(String[] args) {
		
		int userChoice=0;
		
		
		while (userChoice!=3)
		{
			
			System.out.println("Choose UI");
			System.out.println("-------------------------");
			System.out.println("1 � DailyAttractionUsageConsoleUI");
			System.out.println("2 � ParkConsoleUI");
			System.out.println("3 - Exit");
			System.out.print("Enter Choice:");
			
			Scanner choice=new Scanner(System.in);
			userChoice= choice.nextInt();
			
			switch(userChoice)
			{
			case 1:
				DailyAttractionUsageConsoleUI displayDailyUI = new DailyAttractionUsageConsoleUI();
				displayDailyUI.ShowUI();
				break;//End case 1  that shows DailyAttractionUsageConsoleUI's ShowUI method.
			
			case 2:
				ParkConsoleUI displayParkUI = new ParkConsoleUI();
				displayParkUI.ShowUI();
				break;//End case 2 that shows ParkConsoleUI's ShowUI method.
				
			case 3:
				System.out.println("Program end.");
				break;
			
			default:
				System.out.println("Incorrect choice. Choose again");
				break;
			}//End switch
			
		}//End while loop

	}//End main method that began on line 20

}// End Main class
