package grippa.bcs345.hwk.themepark.presentation;

import grippa.bcs345.hwk.themepark.business.DailyAttractionUsage;
import grippa.bcs345.hwk.themepark.business.Park;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains ParkConsoleUI code used to display a menu to user, and use user input to perform actions.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 4/14/17
 *
*/
//Gotta do cases 3,4,5

public class ParkConsoleUI {

	private Park m_Park = new Park();
	
	public void ShowUI()
	{
		int userChoice=0;
		
		
		while (userChoice!=8)
		{
			
			System.out.println("Park UI");
			System.out.println("-------------------------");
			System.out.println("1 � Read park info from file");
			System.out.println("2 � Write park info to file");
			System.out.println("3 � Show attraction by index");
			System.out.println("4 � Show max attraction usage");
			System.out.println("5 - Show park report on screen");
			System.out.println("6 � Show park as JSON string on screen");
			System.out.println("7 � Show park toString on screen");
			System.out.println("8 - Exit");
			System.out.print("Enter Choice:");
			
			Scanner choice=new Scanner(System.in);
			userChoice= choice.nextInt();
		
			switch(userChoice)
			{
			
			case 1:
				System.out.println("Enter input text file name to read the daily usage from (Ex: Park):");
				Scanner ReadfileName=new Scanner(System.in);
				String ParkInputFileName= ReadfileName.next();
				ParkInputFileName+=".txt";
				FileReader ParkfileInput=null;
				
				try 
				{
					ParkfileInput= new FileReader(ParkInputFileName);
				} 
				catch (FileNotFoundException e) 
				{
					System.out.println("\nFatal Error:Input File not found.");
				}		
				
				Scanner s= new Scanner (ParkfileInput);
				
				m_Park.Read(s);
				
				break;//End case 1 Read park info from file
			
			case 2:
				System.out.println("Enter output text file name to write the daily usage to (Ex: ParkOutput):");
				Scanner WritefileName=new Scanner(System.in);
				String ParkOutputFileName= WritefileName.next();
				ParkOutputFileName+=".txt";
				
				PrintStream ps = null;
				try {
					ps = new PrintStream(ParkOutputFileName);
				} catch (FileNotFoundException e) {
					System.out.println("Couldn't print to file.");
				}
				m_Park.Write(ps);
				break;//End case 2 Write park info to file
				
			case 3:
				System.out.println("Enter a index of the array:");
				Scanner indexNum=new Scanner(System.in);
				int index= indexNum.nextInt();
				try{
					m_Park.GetByIndex(index);
				} catch (ArrayIndexOutOfBoundsException i){
					System.out.println("The index you enter is invalid. If you want to try again please run this menu option again.\n");
				}
				break;//End case 3 Show attraction by index
				
			case 4:
				DailyAttractionUsage maxAttraction=m_Park.GetMostDailyUsage();
				System.out.println(maxAttraction.toString()+"\n");
				break;//End case 4 Show max attraction usage
							
			case 5:
					PrintStream ps2=(System.out);
					m_Park.Report(ps2);
				break;//Show park report on screen
			
			case 6:
				System.out.println(m_Park.GetJSON());
				break;//Show park as JSON string on screen
				
			case 7:
				System.out.println(m_Park.toString());
				break;//Show park toString on screen
				
			case 8:
				System.out.println("\nExit Park UI.");
				break;//Ends program.
				
			default:
				System.out.println("Incorrect choice. Choose again");
				break;
			}//End switch
		
		}//End while loop.
		
	}//End of ShowUI

}//End of class
