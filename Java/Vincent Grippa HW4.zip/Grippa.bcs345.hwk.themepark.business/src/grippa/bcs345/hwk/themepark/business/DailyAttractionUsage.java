package grippa.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains DailyAttractionUsage class code.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 3/28/2017
 *
*/

public class DailyAttractionUsage {
	
	private Attraction m_Attraction=new Attraction();
	private CalendarDate m_Date = new CalendarDate();
	private int m_NumRuns;
	private int m_CustomerUsage;
	
	/**
	 * Default constructor. Sets the values of each member variable to a default value.
	 */
	public DailyAttractionUsage()
	{
		m_Attraction= new Attraction();
		m_Date= new CalendarDate();
		m_NumRuns=1;
		m_CustomerUsage=1;
	}//End of default constructor
	
	//Behaviors
		/**
		 * Used to get Attraction info.
		 * @return The Attraction info.
		 */
		public Attraction GetAttraction() {return m_Attraction;}
			
		/**
		 * 
		 * @param newAttraction
		 */
		public void SetAttraction(Attraction newAttraction){ m_Attraction=newAttraction;}
		
		/**
		 * Used to get the date info.
		 * @return The date info.
		 */
		public CalendarDate GetDate() {return m_Date;}
			
		/**
		 * 
		 * @param newDate
		 */
		public void SetDate(CalendarDate newDate){ m_Date=newDate;}
		
		/**
		 * Used to get number of rides.
		 * @return The number of rides.
		 */
		public int GetRuns() {return m_NumRuns;}
			
		/**
		 *
		 * @param newRuns
		 */
		public void SetRuns(int newRuns){ m_NumRuns=newRuns;}
		
		/**
		 * Used to get customer usage.
		 * @return The number of customers who used the ride.
		 */
		public int GetUsage() {return m_CustomerUsage;}
			
		/**
		 *
		 * @param newUsage
		 */
		public void SetUsage(int newUsage){ m_CustomerUsage=newUsage;}
		
		/**
		 * 
		 * @param ps
		 */
		public void Write(PrintStream ps)
		{
			ps.println(m_Attraction.GetName());
			ps.println(m_Attraction.GetCapacity());
			ps.println(m_Attraction.GetDescription());
			ps.println((GetDate()));
			ps.println((GetRuns()));
			ps.println((GetUsage()));
		}
		
		/**
		 * 
		 * @param s
		 */
		public void Read(Scanner s)
		{
			m_Attraction.SetName(s.nextLine());
			m_Attraction.SetCapacity(s.nextInt());
			s.nextLine();
			m_Attraction.SetDescription(s.nextLine());
			m_Date.SetMonth(s.nextInt());
			s.nextLine();
			m_Date.SetDay(s.nextInt());
			s.nextLine();
			m_Date.SetYear(s.nextInt());
			s.nextLine();
			SetRuns(s.nextInt());
			s.nextLine();
			SetUsage(s.nextInt());
			s.nextLine();
		}
		
		/**
		 * 
		 * @return JSON format of DailyAttractionUsage
		 */
		public String GetJSON()
		{
			String JSON=("{\n \"attraction\" :\n{\n\"Name\" : \"" + m_Attraction.GetName() + "\",\n\"Capacity\" : " 
							+ m_Attraction.GetCapacity() + ",\n\"Description\" : \"" + m_Attraction.GetDescription() + "\"\n},\n "
							+ "\"date\" :\n{\n\"month\" : " + m_Date.GetMonth() + ",\n\"day\" : " + m_Date.GetDay() + ",\n\"year\" : " + m_Date.GetYear() + "\n},\n"
							+ "\"numRuns\": " + GetRuns() + "\n\"customerUsage\": " + GetUsage() +"\n}");
			return JSON;
		}
			
		/**
		 * 
		 */
		@Override
		public String toString()
		{
			String toStringText=( "\nAttraction Name: "+ m_Attraction.GetName()+"\nCapacity: "+m_Attraction.GetCapacity()+"\nDescription: "+m_Attraction.GetDescription()
								+"\nDate: "+ m_Date.GetMonth()+"/"+m_Date.GetDay()+"/"+m_Date.GetYear()
								+"\nNumber of Runs:" + GetRuns()
								+"\nNumber of Customers:" +GetUsage() );
			return toStringText;
		}
		
}//End of DailyAttractionUsage Class.
