/**
 * 
 */
/**
 * @author Vincent Grippa
 * @see Contains CalendarDate class, DailyAttractionUsage class, Park class, and Attraction class. This package contains the implementation for the program.
 * 
 */
package grippa.bcs345.hwk.themepark.business;