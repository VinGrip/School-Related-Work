package grippa.bcs345.hwk.themepark.presentation;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import grippa.bcs345.hwk.themepark.business.*;

/**
 * Main entry point for the program.
 * Contains main program code.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 3/11/2017
 *
*/
public class Main {
	//Test code for Write and Read for CalendarDate.
	//Test code for Get/Set for Attraction.
	//Test code for Write and Read for Attraction.

	public static void main(String[] args) {
		//CalendarDate Begin
		System.out.println("The program is automated to test everything for each class.");
		System.out.println("\n---Begin CalendarDate Class test---");
		
		CalendarDate testGetSet = new CalendarDate();
		int validMonth = 1;
		//int validMonth=13; //Invalid month for testing purposes. To use uncomment this line and comment the above line.
		testGetSet.SetMonth(validMonth);
		if (validMonth == testGetSet.GetMonth()) {
			System.out.println("CalendarDate Get/Set Month, Valid Value: Pass");
		} else {
			System.out.println("CalendarDate Get/Set Month, Valid Value: FAIL!");
		}
		
		int validDay= 1;
		//int validDay= 32; //Invalid day for testing purposes. To use uncomment this line and comment the above line.
		testGetSet.SetDay(validDay);
		if (validDay == testGetSet.GetDay()) {
			System.out.println("CalendarDate Get/Set Day, Valid Value: Pass");
		} else {
			System.out.println("CalendarDate Get/Set Day, Valid Value: FAIL!");
		}
		
		int validYear= 2017;
		//int validYear=-1 ; //Invalid year for testing purposes. To use uncomment this line and comment the above line.
		testGetSet.SetYear(validYear);
		if (validYear == testGetSet.GetYear()) {
			System.out.println("CalendarDate Get/Set Year, Valid Value: Pass");
		} else {
			System.out.println("CalendarDate Get/Set Year, Valid Value: FAIL!");
		}

		String CalendarDateinputFileName= "CalendarDate";
		String CalendarDateoutputFileName= CalendarDateinputFileName+"Output.txt";
		CalendarDateinputFileName+=".txt";
		FileReader CalendarDatefileInput=null;
		try 
		{
			CalendarDatefileInput= new FileReader(CalendarDateinputFileName);
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("\nFatal Error:Input File not found.\nNo output given.Program End.");
			System.exit(0);
		}		
		
		Scanner s= new Scanner (CalendarDatefileInput);
		CalendarDate test1= new CalendarDate();
		PrintStream ps = null;
		try {
			ps = new PrintStream(CalendarDateoutputFileName);
		} catch (FileNotFoundException e1) {
			System.out.println("Couldn't print to file.");
		}
		
		test1.Read(s);
		test1.Write(ps);
		System.out.println("CalendarDate Class JSON :"+ test1.GetJSON());
		System.out.println("CalendarDate Class toString :"+ test1.toString());
		
		//The code below is to test that the Write function call above printed information that the below Read function call can read.
		//To truly test delete CalendarDateTest.txt

		FileReader CalendarDatefileTestInput=null;
		try 
		{
			CalendarDatefileTestInput= new FileReader(CalendarDateoutputFileName);
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("\nFatal Error:Input File not found.\nNo output given.Program End.");
			System.exit(0);
		}		
		
		Scanner s2= new Scanner (CalendarDatefileTestInput);
		CalendarDate test2= new CalendarDate();
		PrintStream ps2 = null;
		try {
			ps2 = new PrintStream("CalendarDateTest.txt");
		} catch (FileNotFoundException e) {
			System.out.println("Couldn't print to file.");
		}
		test2.Read(s2);
		test2.Write(ps2);
		
		s.close();
		ps.close();
		s2.close();
		ps2.close();
		
		System.out.println("---End CalendarDate Class test---");
		
		//End CalendarDate
		
		//Begin Attraction
		
		System.out.println("\n---Begin Attraction Class test---");
		
		Attraction testGetSetAtt = new Attraction();
		String validName ="Lion King";
		testGetSetAtt.SetName(validName);
		if (validName == testGetSetAtt.GetName()) {
			System.out.println("Attraction Get/Set Name, Valid Value: Pass");
		} else {
			System.out.println("Attraction Get/Set Name, Valid Value: FAIL!");
		}
		
		int validCap= 1;
		testGetSetAtt.SetCapacity(validCap);
		if (validCap == testGetSetAtt.GetCapacity()) {
			System.out.println("Attraction Get/Set Capacity, Valid Value: Pass");
		} else {
			System.out.println("Attraction Get/Set Capacity, Valid Value: FAIL!");
		}
		
		String validDescr= "Ride related to Lion King.";
		testGetSetAtt.SetDescription(validDescr);
		if (validDescr == testGetSetAtt.GetDescription()) {
			System.out.println("Attraction Get/Set Year, Valid Value: Pass");
		} else {
			System.out.println("Attraction Get/Set Year, Valid Value: FAIL!");
		}
	
		String inputFileName ="Attraction";
		String outputFileName= inputFileName+"Output.txt";
		inputFileName+=".txt";
		FileReader fileInput=null;
		
		try 
		{
			fileInput= new FileReader(inputFileName);
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("\nFatal Error:Input File not found.\nNo output given.Program End.");
			System.exit(0);
		}		
		
		Scanner s3= new Scanner (fileInput);
		Attraction a1= new Attraction();
		PrintStream ps3 = null;
		try {
			ps3 = new PrintStream(outputFileName);
		} catch (FileNotFoundException e) {
			System.out.println("Couldn't print to file.");
		}
		a1.Read(s3);
		a1.Write(ps3);
		System.out.println("Attraction Class JSON :"+ a1.GetJSON());
		System.out.println("Attraction Class toString :"+ a1.toString());
		
		//The code below is to test that the Write function call above printed information that the below Read function call can read.
		//To truly test delete AttractionTest.txt
		
				FileReader fileTestInput=null;
				try 
				{
					fileTestInput= new FileReader(outputFileName);
				} 
				catch (FileNotFoundException e) 
				{
					System.out.println("\nFatal Error:Input File not found.\nNo output given.Program End.");
					System.exit(0);
				}		
				
				Scanner s4= new Scanner (fileTestInput);
				Attraction test3= new Attraction();
				PrintStream ps4 = null;
				try {
					ps4 = new PrintStream("AttractionTest.txt");
				} catch (FileNotFoundException e) {
					System.out.println("Couldn't print to file.");
				}
				test3.Read(s4);
				test3.Write(ps4);
				
				s3.close();
				ps3.close();
				s4.close();
				ps4.close();
				
		System.out.println("---End Attraction Class test---");

	
		//End Attraction
	}

}// End Main class
