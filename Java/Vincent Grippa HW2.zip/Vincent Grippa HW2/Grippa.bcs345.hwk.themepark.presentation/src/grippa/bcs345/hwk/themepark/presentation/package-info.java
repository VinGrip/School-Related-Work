/**
 * 
 */
/**
 * @author Vincent
 * Contains main class to test CalendarDate class, and Attraction class.
 *
 */
package grippa.bcs345.hwk.themepark.presentation;