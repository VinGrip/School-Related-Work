/**
 * 
 */
/**
 * @author Vincent
 *Contains CalendarDate class, and Attraction class.
 */
package grippa.bcs345.hwk.themepark.business;