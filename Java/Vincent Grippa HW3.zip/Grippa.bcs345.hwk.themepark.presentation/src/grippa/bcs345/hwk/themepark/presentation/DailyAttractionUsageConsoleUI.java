package grippa.bcs345.hwk.themepark.presentation;

import grippa.bcs345.hwk.themepark.business.DailyAttractionUsage;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains DailyAttractionUsagConsoleUI code used to display a menu to user, and use user input to perform actions.
 * 
 * @author Vincent Grippa
 * @version 2.0
 * @since 3/26/2017
 *
*/

public class DailyAttractionUsageConsoleUI {
	
	private DailyAttractionUsage m_DailyAttractionUsage = new DailyAttractionUsage();
	
	public void ShowUI()
	{
		int userChoice=0;
		
		
		while (userChoice!=5)
		{
			
			System.out.println("Daily Attraction Usage UI");
			System.out.println("-------------------------");
			System.out.println("1 � Read daily usage from file");
			System.out.println("2 � Write daily usage to file");
			System.out.println("3 � Show daily usage info with descriptive text on screen");
			System.out.println("4 � Show daily usage JSON on screen");
			System.out.println("5 - Exit");
			System.out.print("Enter Choice:");
			
			Scanner choice=new Scanner(System.in);
			userChoice= choice.nextInt();
		
			switch(userChoice)
			{
			
			case 1:
				System.out.println("Enter input text file name to read the daily usage from (Ex: DailyAttractionUsage):");
				Scanner ReadfileName=new Scanner(System.in);
				String DailyAttractionInputFileName= ReadfileName.next();
				DailyAttractionInputFileName+=".txt";
				FileReader DailyAttractionfileInput=null;
				
				try 
				{
					DailyAttractionfileInput= new FileReader(DailyAttractionInputFileName);
				} 
				catch (FileNotFoundException e) 
				{
					System.out.println("\nFatal Error:Input File not found.");
				}		
				
				Scanner s= new Scanner (DailyAttractionfileInput);
				
				m_DailyAttractionUsage.Read(s);
				
				break;//End case 1 Read daily usage from file
			
			case 2:
				System.out.println("Enter output text file name to write the daily usage to (Ex: DailyAttractionUsageOutput):");
				Scanner WritefileName=new Scanner(System.in);
				String DailyAttractionOutputFileName= WritefileName.next();
				DailyAttractionOutputFileName+=".txt";
				
				PrintStream ps = null;
				try {
					ps = new PrintStream(DailyAttractionOutputFileName);
				} catch (FileNotFoundException e) {
					System.out.println("Couldn't print to file.");
				}
				m_DailyAttractionUsage.Write(ps);
				
				break;//End case 2 Write daily usage to file
				
			case 3:
				System.out.println(m_DailyAttractionUsage.toString());
				break;//End case 3 Show daily usage info with descriptive text on screen
				
			case 4:
				System.out.println(m_DailyAttractionUsage.GetJSON());
				break;//End case 4 Show daily usage JSON on screen
			
			case 5:
				System.out.println("\nProgram exit.");
				break;
				
			default:
				System.out.println("Incorrect choice. Chose again.");
				break;
			}//End switch
		
		}//End while loop.
		
	}//End of ShowUI

}//End of class
