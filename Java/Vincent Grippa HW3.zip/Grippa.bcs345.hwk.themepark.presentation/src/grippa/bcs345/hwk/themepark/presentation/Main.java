package grippa.bcs345.hwk.themepark.presentation;

/**
 * Main entry point for the program.
 * Contains main program code.
 * 
 * @author Vincent Grippa
 * @version 2.0
 * @since 3/28/2017
 *
*/
public class Main {

	/**
	 * Code used to call DailyAttractionUsageConsoleUI.
	 * @param args
	 */
	public static void main(String[] args) {
		DailyAttractionUsageConsoleUI displayUI = new DailyAttractionUsageConsoleUI();
		displayUI.ShowUI();
	}

}// End Main class
