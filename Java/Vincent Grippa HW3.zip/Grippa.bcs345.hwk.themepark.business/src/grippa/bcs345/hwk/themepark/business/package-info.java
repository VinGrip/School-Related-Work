/**
 * 
 */
/**
 * @author Vincent Grippa
 * @see Contains CalendarDate class, DailyAttractionUsage class and Attraction class.
 * 
 */
package grippa.bcs345.hwk.themepark.business;