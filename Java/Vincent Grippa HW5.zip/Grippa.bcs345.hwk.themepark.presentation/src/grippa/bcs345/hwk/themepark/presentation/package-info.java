/**
 * 
 */
/**
 * @author Vincent Grippa
 * @see Contains main class to test DailyAttractionUsageConsoleUI class.
 *
 */
package grippa.bcs345.hwk.themepark.presentation;