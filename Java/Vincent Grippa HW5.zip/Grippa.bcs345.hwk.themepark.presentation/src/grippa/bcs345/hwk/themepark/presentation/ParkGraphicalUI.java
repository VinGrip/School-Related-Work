package grippa.bcs345.hwk.themepark.presentation;

import javafx.application.Application;

/**
 * Contains ParkGraphicalUI class code.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 5/8/2017
 *
*/
public class ParkGraphicalUI {
	
	/**
	 * Will launch the ParkApplication class.
	 */
	public void ShowUI(){
		Application.launch(ParkApplication.class);
	}

}