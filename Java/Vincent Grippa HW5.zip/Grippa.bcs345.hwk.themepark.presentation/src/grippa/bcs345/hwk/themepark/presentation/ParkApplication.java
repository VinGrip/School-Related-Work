package grippa.bcs345.hwk.themepark.presentation;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

import grippa.bcs345.hwk.themepark.business.Attraction;
import grippa.bcs345.hwk.themepark.business.DailyAttractionUsage;
import grippa.bcs345.hwk.themepark.business.Park;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;


/**
 * Contains ParkApplication class code.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 5/8/2017
 *
*/
public class ParkApplication extends Application {
	protected Park Park=new Park();
	protected DailyAttractionUsage[] DailyAttractionUsage;
	
	//Variables for GUI display.
	protected VBox mainDisplay;
	
	protected TabPane tabs;
	protected Tab parkTab;
	protected GridPane parkDisplay;
	protected Label parkNameLabel;
	protected Label parkLocationLabel;
	protected Label customerUseLabel;
	protected TextArea parkNameArea;
	protected TextArea parkLocationArea;
	protected TextArea parkUseArea;
	
	protected Tab attractionsTab;
	protected ListView<String> attractionsList;
	
	protected MenuBar basicMenuBar;
	
	@Override
	public void start(Stage mainStage) throws Exception 
	{
		DailyAttractionUsage = new DailyAttractionUsage[4];
		//Set the UI to be called Park Data.
		mainStage.setTitle("Park Data");
		
		//Begin Park tab related code.
		//Set up the parkTab Tab, parkDisplay GridPane, tabs TabPane, and mainDisplay VBox.
		mainDisplay= new VBox();
		parkDisplay = new GridPane();
		tabs = new TabPane();
		parkTab= new Tab();
		parkTab.setClosable(false);
		parkTab.setText("Park");
		
		//Set up labels for parkDisplay.
		parkNameLabel=new Label();
		parkNameLabel.setText("Park Name");
		parkLocationLabel=new Label();
		parkLocationLabel.setText("Park Location");
		customerUseLabel=new Label();
		customerUseLabel.setText("Total Customer Usage");
		
		//Set up text areas for parkDisplay.
		parkNameArea=new TextArea();
		parkNameArea.setPrefColumnCount(10);
		parkNameArea.setPrefRowCount(1);
		
		parkLocationArea=new TextArea();
		parkLocationArea.setPrefColumnCount(10);
		parkLocationArea.setPrefRowCount(1);
		
		parkUseArea=new TextArea();
		parkUseArea.setPrefColumnCount(10);
		parkUseArea.setPrefRowCount(1);
		
		//Add the labels and text boxes for the Park tab.
		parkDisplay.add(parkNameLabel, 0, 0);
		parkDisplay.add(parkLocationLabel, 0, 1);
		parkDisplay.add(customerUseLabel, 0, 3);
		parkDisplay.add(parkNameArea, 1, 0);
		parkDisplay.add(parkLocationArea, 1, 1);
		parkDisplay.add(parkUseArea, 1, 3);
		
		//End Park related code.
		
		//Begin Menu related code.
		//Set up menu related items
		basicMenuBar= new MenuBar();
		SeparatorMenuItem  sep1 = new SeparatorMenuItem();
		SeparatorMenuItem  sep2 = new SeparatorMenuItem();
		SeparatorMenuItem  sep3 = new SeparatorMenuItem();
		
		Menu basicMenu= new Menu("File");
		MenuItem openMenuItem = new MenuItem("Open...");
		ListView<String> list = new ListView<String>();
		ObservableList<String> items =FXCollections.observableArrayList (); 
		openMenuItem.setOnAction( new EventHandler<ActionEvent>() 
		{
		      public void handle(ActionEvent t)
		      {
		    	  FileChooser fileChooser = new FileChooser();
					fileChooser.setTitle("Open Park File");
					File file= fileChooser.showOpenDialog(mainStage);
					
					if (file != null)
					{
						//Intentionally left blank.
					}
					
					FileReader fileInput=null;
					try
					{
						try 
						{
							fileInput= new FileReader(file);
						}
						catch (FileNotFoundException er) 
						{
							System.out.println("\nFatal Error:Input File not found.");
						}
						
						Scanner s= new Scanner (fileInput);
						Park.Read(s);
						parkNameArea.setText(Park.GetName());
						parkLocationArea.setText(Park.GetLocation());
						parkUseArea.setText(Park.customerUse());
						int numOfElements= DailyAttractionUsage.length;
						
						for (int i=0;i<numOfElements;i++)
						{
							items.add(DailyAttractionUsage[i].toString());
							list.setItems(items);
						}					
						
						list.setVisible(true);
						list.setOrientation(Orientation.VERTICAL);
					}//End try starting on line 133.
					catch(NullPointerException i)
					{
						//Intentionally left blank
					}
		      }
		}//End setOnAction
		);//End openMenu item.
		MenuItem saveAsMenuItem = new MenuItem("Save As...");
		saveAsMenuItem.setOnAction( new EventHandler<ActionEvent>() 
		{
		      public void handle(ActionEvent t)
		      {
		    	  FileChooser fileChooser = new FileChooser();
					fileChooser.setTitle("Save As Park");
					File file= fileChooser.showSaveDialog(mainStage);
					
					if (file != null)
					{
						//Intentionally left blank.
					}
					try
					{
						PrintStream ps = null;
						try {
							ps = new PrintStream(file.getName());
						} catch (FileNotFoundException e) {
							System.out.println("Couldn't print to file.");
						}
						System.out.println("**NOTICE TO USER: FILE SAVED INTO PRESENTATION DIRECTORY.**");
						Park.Write(ps);
					}//End try starting on line 170.
					catch(NullPointerException i)
					{
						//Intentionally left blank
					}
		      }
		}//End setOnAction
		);//End saveAsMenu item.
		
		MenuItem saveReportMenuItem = new MenuItem("Save Report...");
		saveReportMenuItem.setOnAction( new EventHandler<ActionEvent>() 
		{
			 public void handle(ActionEvent t)
		      {
		    	  FileChooser fileChooser = new FileChooser();
					fileChooser.setTitle("Save Park Report");
					File file= fileChooser.showSaveDialog(mainStage);
					
					if (file != null)
					{
						//Intentionally left blank.
					}
					
					try
					{
						PrintStream ps = null;
						try {
							ps = new PrintStream(file.getName());
						} catch (FileNotFoundException e) {
							System.out.println("Couldn't print to file.");
						}
						System.out.println("**NOTICE TO USER: FILE SAVED INTO PRESENTATION DIRECTORY.**");
						Park.Report(ps);
					}//End try starting on line 203.
					catch(NullPointerException i)
					{
						//Intentionally left blank
					}
		      }
		}//End setOnAction
		);//End saveReportMenu item.
		
		MenuItem exportJSONMenuItem = new MenuItem("Export As JSON...");
		exportJSONMenuItem.setOnAction( new EventHandler<ActionEvent>() 
		{
			public void handle(ActionEvent t)
		      {
		    	  FileChooser fileChooser = new FileChooser();
					fileChooser.setTitle("Save Park Report");
					File file= fileChooser.showSaveDialog(mainStage);
					
					if (file != null)
					{
						//Intentionally left blank.
					}
					
					try
					{
						PrintStream ps = null;
						try {
							ps = new PrintStream(file.getName());
						} catch (FileNotFoundException e) {
							System.out.println("Couldn't print to file.");
						}
						System.out.println("**NOTICE TO USER: FILE SAVED INTO PRESENTATION DIRECTORY.**");
						ps.print(Park.GetJSON());
					}//End try starting on line 236.
					catch(NullPointerException i)
					{
						//Intentionally left blank
					}
		      }
		}//End setOnAction
		);//End exportJSONMenu item.
		
		MenuItem exitMenuItem = new MenuItem("Exit");
		exitMenuItem.setOnAction( new EventHandler<ActionEvent>() 
		{
		      public void handle(ActionEvent t) {
					System.out.println("Graphical UI Exited.\nProgram terminated.");
					mainStage.close();
					System.exit(0);
		      }
		}//End setOnAction
		);//End exportJSONMenu item.
		
		//Add menu related items to create menu.
		basicMenu.getItems().add(openMenuItem);
		basicMenu.getItems().add(sep1);
		basicMenu.getItems().add(saveAsMenuItem);
		basicMenu.getItems().add(saveReportMenuItem);
		basicMenu.getItems().add(sep2);
		basicMenu.getItems().add(exportJSONMenuItem);
		basicMenu.getItems().add(sep3);
		basicMenu.getItems().add(exitMenuItem);
		basicMenuBar.getMenus().add(basicMenu);	
		
		//Begin Attractions tab related code.
		//Set up the arrtactionsTab Tab.
		attractionsTab= new Tab();
		attractionsTab.setClosable(false);
		attractionsTab.setText("Attractions");
		
				
		//To get the UI to display.
		parkTab.setContent(parkDisplay);
		attractionsTab.setContent(list);
		tabs.getTabs().add(parkTab);
		tabs.getTabs().add(attractionsTab);
		mainDisplay.getChildren().add(basicMenuBar);
		mainDisplay.getChildren().add(tabs);
		Scene scene = new Scene (mainDisplay,600,600);
		mainStage.setScene(scene);
		mainStage.show();
		
		
		
	}//End start function

}//End ParkApplication class
