package grippa.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains Attraction class code.
 * 
 * @author Vincent Grippa
 * @version 2.0
 * @since 3/26/2017
 *
*/
public class Attraction {
	private String m_name;
	private int m_capacity;
	private String m_description;
	
	/**
	 * Default constructor. Sets the values of each member variable to a default value.
	 */
	public Attraction()
	{
		m_name="Placeholder Name";
		m_capacity=1;
		m_description="No description given.";
	}//End of default constructor
	
	/**
	 * Constructor. Sets the values of each member variable to the corresponding parameter values.
	 * @param name
	 * @param capacity
	 * @param description
	 */
	public Attraction(String name, int capacity, String description)
	{
		m_name=name;
		m_capacity=capacity;
		m_description=description;
	}//End of constructor
	
	//Behaviors
	/**
	 * Used to get name of the attraction.
	 * @return The attraction name.
	 */
	public String GetName() {return m_name;}
		
	/**
	 * 
	 * @param newName
	 */
	public void SetName(String newName){ m_name=newName;}
		
	/**
	 * Used to get capacity.
	 * @return The maximum capacity.
	 */
	public int GetCapacity() {return m_capacity;}
		
	/**
	 *
	 * @param newCapacity
	 */
	public void SetCapacity(int newCapacity){ m_capacity=newCapacity;}
		
	/**
	 * Used to get description.
	 * @return The ride description.
	 */
	public String GetDescription() {return m_description;}
		
	/**
	 * 
	 * @param newDescription
	 */
	public void SetDescription(String newDescription){ m_description=newDescription;}
	
	/**
	 * 
	 * @param ps
	 */
	public void Write(PrintStream ps)
	{
		ps.println((GetName()));
		ps.println((GetCapacity()));
		ps.println((GetDescription()));
	}//End Write method.
		
	/**
	 * 
	 * @param s
	 */
	public void Read(Scanner s)
	{
		SetName(s.nextLine());
		SetCapacity(s.nextInt());
		s.nextLine();
		SetDescription(s.nextLine());
	}//End Read method
		
	/**
	 * 
	 * @return JSON format of Attraction
	 */
	public String GetJSON()
	{
		String JSON=("{\"Name\" : \"" + GetName() + "\", \"Capacity\" : " + GetCapacity() + ", \"Description\" : \"" + GetDescription() + "\"}");
		return JSON;
	}
		
	/**
	 * 
	 */
	
	@Override
	public String toString()
	{
		String toStringText=("\nAttraction Name: "+ GetName()+"\nCapacity: "+GetCapacity()+"\nDescription: "+GetDescription());
		return toStringText;
	}

}//End of class
