package grippa.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains Park class code.
 * 
 * @author Vincent Grippa
 * @version 3.0
 * @since 5/9/17
 *
*/
public class Park {
	//Attributes
	private String m_name;
	private String m_location;
	private DailyAttractionUsage[] DailyAttractionUsage;
	
	/**
	 * Default constructor. Sets the values of each member variable to a default value.
	 */
	public Park()
	{
		m_name="Park name";
		m_location="State Name";
		DailyAttractionUsage = new DailyAttractionUsage[4];
		DailyAttractionUsage[0]= new DailyAttractionUsage();//1
		DailyAttractionUsage[1]= new DailyAttractionUsage();//2
		DailyAttractionUsage[2]= new DailyAttractionUsage();//3
		DailyAttractionUsage[3]= new DailyAttractionUsage();//4
	}//End of default constructor
	
	//Behaviors
	/**
	 * Used to get name.
	 * @return The name of the park.
	 */
	public String GetName() {return m_name;}

	/**
	 * 
	 * @param newName
	 */
	public void SetName(String newName)
	{ 
		m_name=newName;
	}

	/**
	 * Used to get location.
	 * @return The location of the park.
	 */
	public String GetLocation() {return m_location;}

	/**
	 * 
	 * @param newLocation
	 */
	public void SetLocation(String newLocation)
	{
		m_location=newLocation;
	}

	/**
	 * 
	 * @param s
	 */
	public void Read(Scanner s)
	{
		SetName(s.nextLine());
		SetLocation(s.nextLine());
		int numOfElements=s.nextInt();
		s.nextLine();
		DailyAttractionUsage = new DailyAttractionUsage[numOfElements];
		for (int i=0;i<numOfElements;i++)
		{
			DailyAttractionUsage[i]= new DailyAttractionUsage();//i+1
			DailyAttractionUsage[i].Read(s);
		}

	}//End read method

	/**
	 * 
	 * @param ps
	 */
	public void Write(PrintStream ps)
	{
		int numOfElements=DailyAttractionUsage.length;

		ps.println(GetName());
		ps.println(GetLocation());
		ps.println(numOfElements);
		for (int i=0;i<numOfElements;i++)
		{
			DailyAttractionUsage[i].Write(ps);
		}
	}//End write method

	/**
	 * 
	 * @param ps
	 */
	public void Report(PrintStream ps)
	{
		int numOfElements=DailyAttractionUsage.length;
		int totalRuns=0;
		int totalCustomers=0;
		Attraction attractionInfo = new Attraction();
		CalendarDate dateInfo= new CalendarDate();

		ps.printf("Park Report\n");
		ps.printf("---------\n");

		//Print the park information
		ps.println(GetName());
		ps.println(GetLocation());

		//To setup the columns for the data.
		ps.println("Attraction Data\n");
		ps.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n","Name","Description","Cap","Mth","Day","Year","Runs","Customers");
		ps.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n", "-----","-----------","---","---","---","----","----","-------");

		for (int i=0;i<numOfElements;i++)
		{
			//To get the information of each type without using toString which would have descriptive text.
			attractionInfo= DailyAttractionUsage[i].GetAttraction();
			dateInfo= DailyAttractionUsage[i].GetDate();
			//To calculate the total number of runs, and customers.
			totalRuns=totalRuns+DailyAttractionUsage[i].GetRuns();;
			totalCustomers=totalCustomers+DailyAttractionUsage[i].GetUsage();
			//To print the attraction info to a line in the output file.
			ps.printf("%-25s %-40.37s %20s %5s %5s %5s %5d %5d \n",attractionInfo.GetName(),attractionInfo.GetDescription(),attractionInfo.GetCapacity(),dateInfo.GetMonth(),dateInfo.GetDay(),dateInfo.GetYear(),DailyAttractionUsage[i].GetRuns(), DailyAttractionUsage[i].GetUsage());
		}
		//To print the total number of runs, and customers.
		ps.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n", "-----","-----------","---","---","---","----","----","-------");
		ps.printf("%-25s %-40.37s %20s %5s %5s %5s %5d %5d \n","Total","","","","","",totalRuns,totalCustomers);


	}//End Report method.	

	/**
	 * 
	 * @return JSON format of Park
	 */
	public String GetJSON()
	{
		String JSON;
		JSON=("{\n\"Name\" : \"" + GetName() + "\",\n\"Location\" : " + GetLocation() + "\",\n\"Dailyattractionusage\" :\n[\n");
		int numOfElements=DailyAttractionUsage.length;
		for(int i=0;i<numOfElements;i++)
		{
			if (i==(numOfElements-1))
			{
				JSON+=(DailyAttractionUsage[i].GetJSON()+"\n");
			}
			else
			{
				JSON+=(DailyAttractionUsage[i].GetJSON()+",\n");
			}
		}
		JSON+="]\n}";

		return JSON;
	}//End JSON method.

	/**
	 * 
	 */
	@Override
	public String toString()
	{
		String toStringText="\nPark Name:"+ GetName() + "\nPark Location:"+ GetLocation() + "\nNumber of Attractions:"+ DailyAttractionUsage.length +"\n";

		int numOfElements=DailyAttractionUsage.length;
		for(int i=0;i<numOfElements;i++)
		{
			toStringText+=(DailyAttractionUsage[i].toString()+"\n");
		}
		return toStringText;
	}//End toString method.

	/**
	 * 
	 * @param index
	 * @return DailyAttractionUsage instance at the given index.
	 */
	public DailyAttractionUsage GetByIndex(int index) throws ArrayIndexOutOfBoundsException
	{
		if ((index>DailyAttractionUsage.length) && (index<0))
		{
			System.out.println(DailyAttractionUsage[index].toString());
			return DailyAttractionUsage[index];
		}
		else
		{
			ArrayIndexOutOfBoundsException i= new ArrayIndexOutOfBoundsException();
			throw i;
		}
	}//End of GetByIndex method.

	/**
	 * 
	 * @return The DailyAttractionUsage instance that had the most customer usage.
	 */

	public DailyAttractionUsage GetMostDailyUsage()
	{
		int index = 0;
		int highestUse=0;;
		for (int i=0; i<(DailyAttractionUsage.length-1);i++)
		{
			if (DailyAttractionUsage[i].GetUsage()< DailyAttractionUsage[i+1].GetUsage() )
			{
				highestUse=DailyAttractionUsage[i+1].GetUsage();
				index=i+1;
			}
			else
			{
				//Intentionally left blank
			}
		}//End for loop.
		return DailyAttractionUsage[index];

	}//End of GetMostDailyUsage method.
	
	public  String customerUse()
	{
		int numOfElements=DailyAttractionUsage.length;
		int totalCustomers=0;
		String customers;
		Attraction attractionInfo = new Attraction();
		for (int i=0;i<numOfElements;i++)
		{
			//To get the information of each type without using toString which would have descriptive text.
			attractionInfo= DailyAttractionUsage[i].GetAttraction();
			//To calculate the total number of customers.
			totalCustomers=totalCustomers+DailyAttractionUsage[i].GetUsage();
		}//End for loop
		customers=""+totalCustomers;
		customers.trim();
		return customers;
		
	}//End of customerUse method.


}//End of class
