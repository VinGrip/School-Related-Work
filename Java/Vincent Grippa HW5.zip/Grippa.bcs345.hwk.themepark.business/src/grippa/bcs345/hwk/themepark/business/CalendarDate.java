package grippa.bcs345.hwk.themepark.business;

import java.io.PrintStream;
import java.util.Scanner;

/**
 * Contains CalendarDate class code.
 * 
 * @author Vincent Grippa
 * @version 2.0
 * @since 3/26/2017
 *
*/
public class CalendarDate {
	//Attributes
	private int m_month;
	private int m_day;
	private int m_year;
	
	/**
	 * Default constructor. Sets the values of each member variable to a default value.
	 */
	public CalendarDate()
	{
		m_month=1;
		m_day=1;
		m_year=2017;
	}//End of default constructor
	
	/**
	 * Constructor. Sets the values of each member variable to the corresponding parameter values.
	 * @param month
	 * @param day
	 * @param year
	 */
	public CalendarDate(int month, int day, int year)
	{
		m_month=month;
		m_day=day;
		m_year=year;
	}//End of constructor
	
	//Behaviors
		/**
		 * Used to get month.
		 * @return The month.
		 */
		public int GetMonth() {return m_month;}
		
		/**
		 * 
		 * @param newMonth
		 */
		public void SetMonth(int newMonth)
		{ 
			if (newMonth>=1)
			{
				if (newMonth<=12)
				{
					m_month=newMonth;
				}
			}
		}
		
		/**
		 * Used to get day.
		 * @return The month.
		 */
		public int GetDay() {return m_day;}
		
		/**
		 * 
		 * @param newDay
		 */
		public void SetDay(int newDay)
		{
			{ 
				if (newDay>=1)
				{
					if (newDay<=31)
					{
						m_day=newDay;
					}
				}
			}
		}
		
		/**
		 * Used to get year.
		 * @return The year.
		 */
		public int GetYear() {return m_year;}
		
		/**
		 * 
		 * @param newYear
		 */
		public void SetYear(int newYear)
		{
			{ 
				if (newYear>=1)
				{
						m_year=newYear;
				}
			}
		}
		
		/**
		 * 
		 * @param ps
		 */
		public void Write(PrintStream ps)
		{
			ps.println((GetMonth()));
			ps.println((GetDay()));
			ps.println((GetYear()));
		}
		
		/**
		 * 
		 * @param s
		 */
		public void Read(Scanner s)
		{
			SetMonth(s.nextInt());
			s.nextLine();
			SetDay(s.nextInt());
			s.nextLine();
			SetYear(s.nextInt());
		}
		
		/**
		 * 
		 * @return JSON format of CalendarDate
		 */
		public String GetJSON()
		{
			String JSON=("{\"month\" : " + GetMonth() + ", \"day\" : " + GetDay() + ", \"year\" : " + GetYear() + "}");
			return JSON;
		}
		
		/**
		 * 
		 */
		@Override
		public String toString()
		{
			String toStringText=(GetMonth()+"/"+GetDay()+"/"+GetYear());
			return toStringText;
		}
	
	
}//End of class
