/**
 * @author Vincent Grippa
 * Contains a class to generate a report on theme park data.
 *
 */
package grippa.bcs345.hwk.themepark.standalonereport;