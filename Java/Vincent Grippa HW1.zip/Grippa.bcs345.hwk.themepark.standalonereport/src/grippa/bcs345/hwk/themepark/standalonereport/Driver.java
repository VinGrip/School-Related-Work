package grippa.bcs345.hwk.themepark.standalonereport;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;

/**
 * Main entry point for the program.
 * Contains main program code. This class generates a report about park data taken from a file.
 * The report is then printed to the user defined file.
 * 
 * @author Vincent Grippa
 * @version 1.0
 * @since 2/12/2017
 *
*/
public class Driver {
	
/**
 * 
 * Program entry point.
 * 
 * @param args
 * 
 */

	public static void main(String[] args) {
		//Variable declarations
		String parkName=null;
		String parkLocation = null;
		int numOfAttractions=0;
		String attractionName = null;
		String attractionCap=null;
		String attractionDescript = null;
		String month = null;
		String day = null;
		String year = null;
		int numRuns=0;
		int customerUsage=0;
		int totalRuns=0;
		int totalCustomers=0;
		
		System.out.println("----Program Begin.----\n");
		
		//To allow user input.
		Scanner input= new Scanner(System.in);
		
		//To get input file name.
		System.out.printf("Enter the input file (Ex: Park.txt):");
		String inputFile=input.nextLine();
		System.out.printf("\n");
		
		//To get output file name.
		System.out.printf("Enter the output file (Ex: Report.txt):");
		String outputFile= input.nextLine();
		
		input.close();
		
		//To read the file.
		FileReader fileInput=null;
		try 
		{
			fileInput= new FileReader(inputFile);
		} 
		catch (FileNotFoundException e) 
		{
			System.out.println("\nFatal Error:Input File not found.\nNo output given.Program End.");
			System.exit(0);
		}
		//To input from the file.
		Scanner fileRead= new Scanner(fileInput);
		
		//To gather basic information about park.
		parkName=fileRead.nextLine();
		parkLocation=fileRead.nextLine();
		numOfAttractions=fileRead.nextInt();
		fileRead.nextLine();
		
		//To print to output file.
				PrintStream fileOut=null;
				try {
					fileOut= new PrintStream(outputFile);
				} catch (FileNotFoundException e) {
					System.out.println("Can't print this file for some reason.");
				}
				
				fileOut.printf("Park Report\n");
				fileOut.printf("---------\n");
				
				//Print the park information
				fileOut.println(parkName +"\n");
				fileOut.println(parkLocation +"\n");
				
				//To setup the columns for the data.
				fileOut.println("Attraction Data\n");
				fileOut.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n","Name","Description","Cap","Mth","Day","Year","Runs","Customers");
				fileOut.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n", "-----","-----------","---","---","---","----","----","-------");
		
		
		//To get attraction info.
		while (fileRead.hasNextLine())
		{
			for (int i=0;i<numOfAttractions;i++)
			{
				attractionName=fileRead.nextLine();
				attractionCap=fileRead.nextLine();
				attractionDescript=fileRead.nextLine();
				month=fileRead.nextLine();
				day=fileRead.nextLine();
				year=fileRead.nextLine();
				numRuns=fileRead.nextInt();
				fileRead.nextLine();
				customerUsage=fileRead.nextInt();
				fileRead.nextLine();
				
			//To calculate the total number of runs, and customers.
				totalRuns=totalRuns+numRuns;
				totalCustomers=totalCustomers+customerUsage;
				
			//To print the attraction info to a line in the output file.
				fileOut.printf("%-25s %-40.37s %20s %5s %5s %5s %5d %5d \n",attractionName,attractionDescript,attractionCap,month,day,year,numRuns,customerUsage);
				
				
			}//End for loop beginning at line 66.
			
			//To print the total number of runs, and customers.
			fileOut.printf("%-25s %-40s %20s %5s %5s %5s %5s %5s\n", "-----","-----------","---","---","---","----","----","-------");
			fileOut.printf("%-25s %-40.37s %20s %5s %5s %5s %5d %5d \n","Total","","","","","",totalRuns,totalCustomers);
		}//End while loop beginning at line 64.
		
		
		System.out.println("\n----Program End.----");
		fileRead.close();
		
	}//End Main.
	
}//End Driver.
